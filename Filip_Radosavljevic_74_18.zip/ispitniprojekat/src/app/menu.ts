export interface Menu {
    id:number,
    naziv:string,
    path:string
}
