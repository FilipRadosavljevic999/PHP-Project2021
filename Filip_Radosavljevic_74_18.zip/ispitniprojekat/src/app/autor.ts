export interface Autor {
    idAutor:number,
    src:string,
    alt:string
    opis:number
}
