export const base_url={
    base_url:"http://localhost:4200/assets/data/"
}
export const paths={
    
    proizvodi:base_url.base_url+"Satovi.json",
    menu:base_url.base_url+"meni.json",
    grad:base_url.base_url+"grad.json",
    autor:base_url.base_url+"autor.json",
    adresa:base_url.base_url+"adresa.json"
}