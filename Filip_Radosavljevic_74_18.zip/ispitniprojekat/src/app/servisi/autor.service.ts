import { Autor } from './../autor';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { paths } from '../paths';


@Injectable({
  providedIn: 'root'
})
export class AutorService {

  constructor(private autroserrvis:HttpClient) { }
  
  getAutor(){
    let niz=this.autroserrvis.get(paths.autor)
    return niz
  }
}
