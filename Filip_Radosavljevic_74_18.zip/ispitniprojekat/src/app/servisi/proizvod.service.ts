import { paths } from './../paths';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProizvodService {

  constructor(private servis:HttpClient) { }
  getProizvodi(){
    let proizvodi=this.servis.get(paths.proizvodi)
    return proizvodi
  }
}
