import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { paths } from '../paths';
@Injectable({
  providedIn: 'root'
})
export class AdresaService {

  constructor(private servis:HttpClient) { }
  getAdresa(){
    let adresa=this.servis.get(paths.adresa);
    return adresa 
  }
}
