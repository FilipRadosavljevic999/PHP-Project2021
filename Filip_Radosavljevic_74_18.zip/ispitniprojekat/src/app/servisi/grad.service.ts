import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { paths } from '../paths';
@Injectable({
  providedIn: 'root'
})
export class GradService {

  constructor(private service:HttpClient) { }
  getGrad(){
    let grad=this.service.get(paths.grad);
    return grad;
  }
}
