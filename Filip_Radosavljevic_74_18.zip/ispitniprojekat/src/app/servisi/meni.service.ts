import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {paths} from '../paths';

@Injectable({
  providedIn: 'root'
})
export class MeniService {

  constructor(private service:HttpClient) { }
  getMeni(){
    let meni=this.service.get(paths.menu)
    return meni
  }
}
