export interface Adresas {
    adresa:string,
    radno:string,
    subota:string,
    kontakt:string,
    email:string
}
