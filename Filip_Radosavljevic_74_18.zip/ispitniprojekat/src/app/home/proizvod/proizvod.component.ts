import { satovi } from './../../satovi';
import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-proizvod',
  templateUrl: './proizvod.component.html',
  styleUrls: ['./proizvod.component.css']
})
export class ProizvodComponent implements OnInit {

  constructor() { }
  @Input() p!:satovi;// p je od jedanproizvod
  
  
  
  ngOnInit(): void {
   
  }

}
