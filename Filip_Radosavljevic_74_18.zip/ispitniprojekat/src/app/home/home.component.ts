import { MeniService } from './../servisi/meni.service';
import { ProizvodService } from './../servisi/proizvod.service';
import { satovi } from './../satovi';

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private proizvodservis:ProizvodService) { }
  public items:satovi[]=[];
  min:string="";
  max:string="";
  
  ngOnInit(): void {
    this.proizvodservis.getProizvodi().subscribe(
      (Response:any)=>{
        this.items=Response;
        console.log(this.items)
      },
      error=>{
        alert(error)
      }
    )
  }
  
  
 /* klikni(f:any){
   //let  data:satovi[]=this.items
    
    let minimalni=f.value.min
    let maximalni=f.value.max
    
    if(minimalni==""){
      minimalni=0
    }
    if(maximalni==""){
      maximalni=600000000
    }
    //let item=data.forEach(x=>{x.Cena<maximalni&& x.Cena>minimalni})
    //console.log(item)
    
  }*/
  

}
