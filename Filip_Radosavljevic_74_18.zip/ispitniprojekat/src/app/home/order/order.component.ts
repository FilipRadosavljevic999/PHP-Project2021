import { Grad } from './../../grad';
import { Component, OnInit } from '@angular/core';
import { GradService } from 'src/app/servisi/grad.service';
import { ProizvodService } from 'src/app/servisi/proizvod.service';
import { satovi } from 'src/app/satovi';
import { FormGroup, NgForm,FormControl,Validators,ReactiveFormsModule } from '@angular/forms';
import { trigger, state, style, transition, animate } from '@angular/animations';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
  animations:[
    trigger("showHide", [
      state('true', style({transform: 'scale(1)'})),
      state('false', style({transform: 'scale(0)'})),
      transition('false<=>true', animate('800ms ease'))
    ])
  ]
})
export class OrderComponent implements OnInit {

  constructor(private proizvodservic:ProizvodService, private gradservis:GradService) { }
  public proizvodbrend:satovi[]=[]
  public gradovi:Grad[]=[]
  public postanski:string=""
  public greske=[]
  
  contactForm !: FormGroup ;
  poruka: boolean = false;
  
  ngOnInit(): void {
    this.proizvodservic.getProizvodi().subscribe(
      (Response:any)=>
      {
        this.proizvodbrend=Response;
      }
    )
    this.gradservis.getGrad().subscribe(
      (Response:any)=>{
        this.gradovi=Response;
        console.log(this.gradovi)
      }
    )
    this.contactForm=new FormGroup({
      product:new FormControl("1"),
      ime:new FormControl(null,[Validators.required,Validators.pattern('[A-ZČĆŠĐŽ][a-zčćšđž]{1,14}(\s[A-ZČĆŠĐŽ][a-zčćšđž]{1,19}){0,}')]),
      prezime:new FormControl("",[Validators.required,Validators.pattern('[A-ZČĆŠĐŽ][a-zčćšđž]{1,14}(\s[A-ZČĆŠĐŽ][a-zčćšđž]{1,19}){0,}')]),
      adresa:new FormControl("",[Validators.required,Validators.pattern('[A-ZČĆŠĐŽ][a-zčćšđž]{2,15}(\s[A-ZČĆŠĐŽ][a-zčćšđž]{0,10}){0,4}\s([0-9]{1,3}|[0-9]{1,3}[a-z])')]),
      grad:new FormControl("1"),
      broj:new FormControl("",[Validators.required,Validators.pattern('[A-ZČĆŠĐŽ][a-zčćšđž]{1,14}(\s[A-ZČĆŠĐŽ][a-zčćšđž]{1,19}){0,}')])
    })
    


  }
  onKlik(){
   this.poruka=true
   this.contactForm.reset
  }
}
