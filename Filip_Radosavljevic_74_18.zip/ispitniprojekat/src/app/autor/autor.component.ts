import { trigger, state, style, transition, animate, } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { AutorService } from '../servisi/autor.service';
import { Autor } from '../autor';

@Component({
  selector: 'app-autor',
  templateUrl: './autor.component.html',
  styleUrls: ['./autor.component.css'],
 
})
export class AutorComponent implements OnInit {

  constructor(private servis:AutorService) { }
  public autor:Autor[]=[]

  ngOnInit(): void {
    this.servis.getAutor().subscribe(
      (Response:any)=>{
        this.autor=Response
        console.log(this.autor);
      }
    )
  }

}
