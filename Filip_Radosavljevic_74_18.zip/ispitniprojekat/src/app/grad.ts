export interface Grad {
    idGrad:number,
    Naziv:string,
    PostanskiBroj:number
}
