import { Menu } from './../menu';
import { MeniService } from './../servisi/meni.service';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-meni',
  templateUrl: './meni.component.html',
  styleUrls: ['./meni.component.css']
})
export class MeniComponent implements OnInit {

  constructor(private meniservis:MeniService) { }
  public meni:Menu[]=[]

  ngOnInit(): void {
    this.meniservis.getMeni().subscribe(
      (Response:any)=>{
        this.meni=Response
        console.log(this.meni)
      },
      error=>{
        alert(error)
      }
      
    )
  }

}
