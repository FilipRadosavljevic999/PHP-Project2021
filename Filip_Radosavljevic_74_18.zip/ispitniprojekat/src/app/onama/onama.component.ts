import { Component, OnInit } from '@angular/core';
import { AdresaService } from '../servisi/adresa.service';
import { Adresas } from '../adresa';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { trigger, state, style, transition, animate } from '@angular/animations';

@Component({
  selector: 'app-onama',
  templateUrl: './onama.component.html',
  styleUrls: ['./onama.component.css'],
  animations:[
    trigger("showHide", [
      state('true', style({transform: 'scale(1)'})),
      state('false', style({transform: 'scale(0)'})),
      transition('false<=>true', animate('800ms ease'))
    ])
  ]
})
export class OnamaComponent implements OnInit {

  constructor(private adresaservis:AdresaService) { }
  public adresa:Adresas[]=[]
  kontakt!:FormGroup;
  poslato:boolean=false
  ngOnInit(): void {
    this.adresaservis.getAdresa().subscribe(
      (Response:any)=>{
        this.adresa=Response
        console.log(this.adresa)
      }
    )
    this.kontakt=new FormGroup({
      ime : new FormControl("", [Validators.required, Validators.pattern('^[A-ZČĆŠĐŽ][a-zčćšđž]{1,14}(\s[A-ZČĆŠĐŽ][a-zčćšđž]{1,19}){0,}$')]),
      email : new FormControl("", [Validators.required, Validators.email]),
      poruka : new FormControl("", [Validators.required, Validators.minLength(5), Validators.maxLength(300)])
    })

  }
  onFormSubmit(){
    this.poslato=true;
    this.kontakt.reset();
  }

}
