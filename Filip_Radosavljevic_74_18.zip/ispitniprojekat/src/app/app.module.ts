import { RouterModule, Routes } from '@angular/router';
import { NgModule, Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HeaderComponent } from './header/header.component';
import { MeniComponent } from './meni/meni.component';
import { AutorComponent } from './autor/autor.component';
import { OnamaComponent } from './onama/onama.component';
import { FooterComponent } from './footer/footer.component';
import { ProizvodComponent } from './home/proizvod/proizvod.component';
import { OrderComponent } from './home/order/order.component';
const appRoute:Routes=[
    {
      path:"",
      component:HomeComponent
    },
    {
      path:"autor",
      component:AutorComponent
    },
    {
      path:"nama",
      component:OnamaComponent
    }

]
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    MeniComponent,
    AutorComponent,
    OnamaComponent,
    FooterComponent,
    ProizvodComponent,
    OrderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot(appRoute),
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
